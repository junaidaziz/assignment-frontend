const randomTask = require('./Task')

module.exports = {
  randomTask,
}
